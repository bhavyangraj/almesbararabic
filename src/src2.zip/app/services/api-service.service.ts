import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ApiServiceService {
  // basePath = 'https://backend.almesbar.net/api/v1/';
  basePath = 'http://localhost:5000/api/v1/';
  // basePath = 'https://almesbarbackend-2.vercel.app/api/v1/';

  constructor(
    private router: Router,
    private http: HttpClient,
  ) {}

  getAll(url: any, search: string, page: number, pagesize: number) {
    if (search) {
      return this.http.get<[]>(
        this.basePath +
          url +
          '?searchTerm=' +
          encodeURIComponent(search) +
          '&page=' +
          page +
          '&limit=' +
          pagesize,
        {
          headers: { ['Content-Type']: 'application/json;charset=UTF-8' },
        },
      );
    } else {
      return this.http.get<[]>(
        this.basePath + url + '?page=' + page + '&limit=' + pagesize,
        {
          headers: { ['Content-Type']: 'application/json' },
        },
      );
    }
  }

  getFull(url: any) {
    return this.http.get<[]>(this.basePath + url + '/getall', {
      headers: { ['Content-Type']: 'application/json' },
    });
  }

  get_all(url: any) {
    return this.http.get<[]>(this.basePath + url + '/all', {
      headers: { ['Content-Type']: 'application/json' },
    });
  }

  getFull2(url: any) {
    return this.http.get<[]>(this.basePath + url + '/getall', {
      headers: { ['Content-Type']: 'application/json' },
    });
  }

  getPdfProxyUrl(url: any): any {
    return `${this.basePath}pdf?url=${encodeURIComponent(url)}`;
  }

  downloadPdf(url: any): any {
    return `${this.basePath}downloadpdf?url=${encodeURIComponent(url)}`;
  }

  getBooks(
    url: any,
    search: string,
    page: number,
    pagesize: number,
    filter: any,
  ) {
    if (search || filter) {
      return this.http.get<[]>(
        this.basePath +
          url +
          '?searchTerm=' +
          encodeURIComponent(search) +
          '&page=' +
          page +
          '&limit=' +
          pagesize +
          '&filter=' +
          filter,

        {
          headers: { ['Content-Type']: 'application/json;charset=UTF-8' },
        },
      );
    } else {
      return this.http.get<[]>(
        this.basePath + url + '?page=' + page + '&limit=' + pagesize,
        {
          headers: { ['Content-Type']: 'application/json' },
        },
      );
    }
  }

  getSearch(url: any, search: string, page: number, pagesize: number) {
    return this.http.get<[]>(
      this.basePath +
        url +
        '?query=' +
        encodeURIComponent(search) +
        '&page=' +
        page +
        '&limit=' +
        pagesize,

      {
        headers: { ['Content-Type']: 'application/json;charset=UTF-8' },
      },
    );
  }

  getShop(
    url: any,
    search: string,
    page: number,
    pagesize: number,

    type?: string,
    ebookOnly?: boolean,
  ) {
    if (search || ebookOnly || type) {
      return this.http.get<[]>(
        this.basePath +
          url +
          '?searchTerm=' +
          encodeURIComponent(search) +
          '&type=' +
          type +
          '&ebookOnly=' +
          ebookOnly +
          '&page=' +
          page +
          '&limit=' +
          pagesize,

        {
          headers: { ['Content-Type']: 'application/json;charset=UTF-8' },
        },
      );
    } else {
      return this.http.get<[]>(
        this.basePath + url + '?page=' + page + '&limit=' + pagesize,
        {
          headers: { ['Content-Type']: 'application/json' },
        },
      );
    }
  }

  get(url: any, id: any) {
    return this.http.get<[]>(this.basePath + url + '/' + id, {
      headers: { ['Content-Type']: 'application/json' },
    });
  }

  getList(url: any) {
    return this.http.get<[]>(this.basePath + url, {
      headers: { ['Content-Type']: 'application/json' },
    });
  }

  getAuthorData(authorname: any) {
    return this.http.get<[]>(this.basePath + 'searchall?author=' + authorname, {
      headers: { ['Content-Type']: 'application/json' },
    });
  }

  getArabicName(data: any) {
    if (data == 'articles') {
      return 'مقالات';
    } else if (data == 'generals') {
      return 'مفاهيم عامة';
    } else if (data == 'philosophicals') {
      return 'مفاهيم فلسفية';
    } else if (data == 'audiobooks') {
      return 'كتب صوتية';
    } else if (data == 'interviews') {
      return 'مقابلات';
    } else if (data == 'studies') {
      return 'دراسات';
    } else if (data == 'studies_in_tolerances') {
      return 'دراسات في التسامح';
    } else if (data == 'taliban') {
      return 'طالبان';
    } else if (data == 'probe_in_medias') {
      return 'المسبار في الإعلام';
    } else if (data == 'files') {
      return 'ملفات';
    } else if (data == 'videos') {
      return 'فيديو المسبار';
    } else if (data == 'highdebate') {
      return 'سجالات رفيعة';
    } else if (data == 'summary') {
      return 'ملخصات';
    } else if (data == 'probe_libraries') {
      return 'مكتبة المسبار';
    } else if (data == 'books') {
      return 'كتب المركز';
    } else if (data == 'AMessageFromNewyork') {
      return 'رسالة من نيويورك';
    } else if (data == 'CenterNews') {
      return 'اخبار المركز';
    } else if (data == 'Covid19Pandemic') {
      return 'جائحة (كوفيد -19)';
    } else if (data == 'Editorials') {
      return 'مقالات رئيس التحرير';
    } else if (data == 'Immigration') {
      return 'الهجرة';
    } else if (data == 'LebaneseIslamists') {
      return 'إسلاميو لبنان';
    } else if (data == 'Mainmajor') {
      return 'رئيسي';
    } else if (data == 'OtherPaths') {
      return 'مسارات أخرى';
    } else if (data == 'PopeFrancisVisit') {
      return 'زيارة البابا فرنسيس';
    } else if (data == 'ReadingReport') {
      return 'قراءة في تقرير';
    } else if (data == 'SupportingWomenWeakensExtremism') {
      return 'دعم المرأة يمرض التطرف';
    } else if (data == 'TeachingPhilosophy') {
      return 'تدريس الفلسفة';
    } else if (data == 'TheCenterWrote') {
      return 'كتب المركز';
    } else if (data == 'Translations') {
      return 'ترجمات';
    } else if (data == 'WeeklyReports') {
      return 'تقارير أسبوعية';
    } else if (data == 'areport') {
      return 'تقرير';
    } else if (data == 'ediorpick') {
      return 'اختيارات المحرر';
    } else if (data == 'dialouge') {
      return 'حوارات';
    } else if (data == 'readingabook') {
      return 'قراءة في كتاب';
    } else if (data == 'selection') {
      return 'مختارات';
    } else if (data == 'September11Events') {
      return 'أحداث 11سبتمبر';
    } else if (data == 'infographics') {
      return 'إنفوجرافيك';
    } else if (data == 'iranianstudies') {
      return 'دراسات إيرانيّة';
    } else {
      return 'Others';
    }
  }
}
