import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SharedDataService {
  private studiesInToleranceSource = new BehaviorSubject<any[]>([]);
  private iranianStudiesSource = new BehaviorSubject<any[]>([]);

  studiesInTolerance$ = this.studiesInToleranceSource.asObservable();
  iranianStudies$ = this.iranianStudiesSource.asObservable();

  setStudiesInTolerance(data: any[]) {
    this.studiesInToleranceSource.next(data);
  }

  setIranianStudies(data: any[]) {
    this.iranianStudiesSource.next(data);
  }

  getStudiesInTolerance() {
    return this.studiesInToleranceSource.value;
  }

  getIranianStudies() {
    return this.iranianStudiesSource.value;
  }
}
