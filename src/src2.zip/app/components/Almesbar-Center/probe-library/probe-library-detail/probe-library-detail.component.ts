import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ApiServiceService } from './../../../../services/api-service.service';
import { NgxPrintDirective } from 'ngx-print';
import { SocialLinksComponent } from '../../../social-links/social-links.component';
import { EndingsectionComponent } from '../../../endingsection/endingsection.component';

@Component({
  selector: 'app-probe-library-detail',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NgbModule,
    NgxPrintDirective,
    SocialLinksComponent,
    EndingsectionComponent,
  ],
  templateUrl: './probe-library-detail.component.html',
  styleUrls: ['./probe-library-detail.component.css'],
})
export class ProbeLibraryDetailComponent implements OnInit {
  constructor(
    private apiService: ApiServiceService,
    private router: Router,
    private route: ActivatedRoute,
  ) {
    let url = router.url.split('/');
    this.id = url[3];
  }

  books: any = {};
  url = 'probelibrary';
  id: any;
  fontSize = 28;
  items = [
    { label: 'الخط 1', value: 'YourCustomFontName2' },
    {
      label: 'الخط 2',
      value: 'Noto Kufi Arabic,ui-sans-serif,Helvetica Neue,sans-serif',
    },

    {
      label: 'الخط 3',
      value: 'Tajawal',
    },
    {
      label: 'الخط 4',
      value: 'Amiri Quran',
    },
  ];
  results: any[] = [];
  isLoading = false;
  search = '';
  pageSize = 50;
  pageSizes = [15, 30, 50];
  size = 0;
  totalPages: any;
  public isActive: any = true;
  url3 = 'getAllAuthors';
  url4 = 'researchers';
  page = 1;
  authorData: any[] = [];

  // Preselect one item
  selectedItem = 'YourCustomFontName2';

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.id = params.get('id');
      // if (localStorage.getItem('id')) {
      //   this.id = localStorage.getItem('id');
      // }
      this.get();

      if (window.innerWidth <= 576) {
        this.fontSize = 18; // mobile
      } else {
        this.fontSize = 28; // desktop
      }
    });
  }

  get() {
    this.apiService.get(this.url, this.id).subscribe(
      (data: any) => {
        // // console.log(data);
        this.books = data.data;
        if (this.books.author_arabic) {
          this.getAuthor();
        }
      },
      (error: any) => {
        // console.log(error);
      },
    );
  }

  getAuthor() {
    this.apiService
      .getAll(this.url3, this.search, this.page, this.pageSize)
      .subscribe(
        (data: any) => {
          this.authorData = data.data;
          this.authorData = data.data.filter(
            (item: any) => item.author_arabic === this.books.author_arabic,
          );
          if (this.authorData.length == 0) {
            this.get3();
          }
          // // console.log(this.authorData);
          this.size = data.count;
        },
        (error) => {
          // console.log(error);
        },
      );
  }

  get3() {
    this.apiService
      .getAll(this.url4, this.search, this.page, this.pageSize)
      .subscribe(
        (data: any) => {
          this.authorData = data.data;
          this.authorData = data.data.filter(
            (item: any) => item.author_arabic === this.books.author_arabic,
          );

          this.size = data.count;
        },
        (error) => {
          // console.log(error);
        },
      );
  }

  gotoDetailPage(id: any, id2: any) {
    localStorage.setItem('id', id2);
    this.router.navigate(['/probelibrary/' + id + '/' + id2]);
    setTimeout(() => {
      window.location.reload();
      setTimeout;
    }, 500);
  }

  get2() {
    let page = 1;
    if (this.isLoading) return; // avoid duplicate requests
    this.isLoading = true;

    this.apiService
      .getAll(this.url, this.search, page, this.pageSize)
      .subscribe(
        (data: any) => {
          this.results = data.data;

          this.totalPages = data.totalPages;
          this.isLoading = false;
          this.size = data.count;
        },
        (error) => {
          // console.log(error);
        },
      );
  }

  onContentClick(event: Event) {
    const target = event.target as HTMLElement;
    if (target.tagName.toLowerCase() === 'a') {
      const href = target.getAttribute('href');
      if (href && href.startsWith('#')) {
        event.preventDefault();
        const el = document.querySelector(href);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }
    }
  }

  changeFontSize(action: 'smaller' | 'bigger') {
    if (action === 'smaller' && this.fontSize > 10) {
      this.fontSize -= 2;
    } else if (action === 'bigger' && this.fontSize < 40) {
      this.fontSize += 2;
    }
  }

  getUrl(data: any) {
    return window.location.href;
  }
}
