import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Component, OnInit, HostListener } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ApiServiceService } from '../../services/api-service.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SocialLinksComponent } from '../social-links/social-links.component';

@Component({
  selector: 'app-viewcomponent',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NgbModule,
    SocialLinksComponent,
  ],
  templateUrl: './viewcomponent.component.html',
  styleUrl: './viewcomponent.component.css',
})
export class ViewcomponentComponent {
  studies: any[] = [];
  page = 1;
  pageSize = 10;
  pageSizes = [10, 50, 100, 200, 300, 400];
  size = 0;
  public isActive: any = true;
  search = '';
  url = 'studies';
  hideImages = true;
  loading = false;
  totalPages: any;
  results: any[] = [];
  isLoading = false;

  constructor(
    private apiService: ApiServiceService,
    private router: Router,
    private route: ActivatedRoute,
  ) {}

  ngOnInit(): void {
    if (this.router.url.split('/')[1] == 'areports') {
      this.url = 'areport';
    } else if (this.router.url.split('/')[1] == 'dialouges') {
      this.url = 'dialouge';
    } else if (this.router.url.split('/')[1] == 'ediorspicks') {
      this.url = 'ediorpick';
    } else if (this.router.url.split('/')[1] == 'selections') {
      this.url = 'selection';
    } else if (this.router.url.split('/')[1] == 'amessagefromnewyork') {
      this.url = 'AMessageFromNewyork';
    } else if (this.router.url.split('/')[1] == 'popefrancisvisit') {
      this.url = 'PopeFrancisVisit';
    } else if (this.router.url.split('/')[1] == 'readingreport') {
      this.url = 'ReadingReport';
    } else if (this.router.url.split('/')[1] == 'thecenterwrotes') {
      this.url = 'TheCenterWrote';
    } else if (this.router.url.split('/')[1] == 'otherpaths') {
      this.url = 'OtherPaths';
    } else if (this.router.url.split('/')[1] == 'editorials') {
      this.url = 'Editorials';
    } else if (this.router.url.split('/')[1] == 'readingabooks') {
      this.url = 'readingabook';
    } else if (this.router.url.split('/')[1] == 'mainmajors') {
      this.url = 'Mainmajor';
    } else if (
      this.router.url.split('/')[1] == 'supportingwomenweakensextremism'
    ) {
      this.url = 'SupportingWomenWeakensExtremism';
    } else if (this.router.url.split('/')[1] == 'covid19pandemics') {
      this.url = 'Covid19Pandemic';
    } else if (this.router.url.split('/')[1] == 'weeklyreports') {
      this.url = 'WeeklyReports';
    } else if (this.router.url.split('/')[1] == 'translations') {
      this.url = 'Translations';
    } else if (this.router.url.split('/')[1] == 'teachingphilosophies') {
      this.url = 'TeachingPhilosophy';
    } else if (this.router.url.split('/')[1] == 'lebaneseislamists') {
      this.url = 'LebaneseIslamists';
    } else if (this.router.url.split('/')[1] == 'centernews') {
      this.url = 'CenterNews';
    } else if (this.router.url.split('/')[1] == 'immigrations') {
      this.url = 'Immigration';
    } else if (this.router.url.split('/')[1] == 'september11events') {
      this.url = 'September11Events';
    }

    this.get();
  }
  reset() {
    this.studies = [];
    this.page = 1;
  }

  getName() {
    return this.apiService.getArabicName(this.url);
  }

  get() {
    if (this.loading || this.page > this.totalPages) return;
    this.loading = true;
    this.apiService
      .getAll(this.url, this.search, this.page, this.pageSize)
      .subscribe(
        (data: any) => {
          this.studies = [...this.studies, ...data.data];
          this.page++;
          this.totalPages = data.totalPages;
          this.loading = false;

          this.size = data.count;
        },
        (error) => {},
      );
  }

  get2() {
    let page = 1;
    if (this.isLoading) return;
    this.isLoading = true;

    this.apiService
      .getAll(this.url, this.search, page, this.pageSize)
      .subscribe(
        (data: any) => {
          this.results = data.data;

          this.totalPages = data.totalPages;
          this.isLoading = false;
          this.size = data.count;
        },
        (error) => {},
      );
  }

  handlePageSizeChange(): void {
    this.page = 1;
    this.ngOnInit();
  }

  pageChange(event: any) {
    this.page = event;
    window.scrollTo(0, 0);
    this.get();
  }

  isLongText(text: any): boolean {
    return text && text.length > 300;
  }

  openInNewTab(id: string) {
    this.router.navigate(['/' + this.router.url.split('/')[1] + '/' + id]);
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const pos =
      (document.documentElement.scrollTop || document.body.scrollTop) +
      window.innerHeight;
    const max = document.documentElement.scrollHeight;

    if (pos >= max - 2000) {
      this.get();
    }
  }

  getUrl(data: any) {
    return window.location.href + '/' + data;
  }
}
