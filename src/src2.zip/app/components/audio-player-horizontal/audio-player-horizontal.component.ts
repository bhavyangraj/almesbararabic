import { CommonModule } from '@angular/common';
import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
  Input,
  AfterViewInit,
  SimpleChanges,
} from '@angular/core';

@Component({
  selector: 'app-audio-player-horizontal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './audio-player-horizontal.component.html',
  styleUrl: './audio-player-horizontal.component.css',
})
export class AudioPlayerHorizontalComponent {
  private audio: HTMLAudioElement | null = null;

  isPlaying = false;
  isLoaded = false;
  currentTime = '0:00';
  duration = '0:00';
  progressScale = 0;

  @Input() trackUrl =
    'https://files.freemusicarchive.org/storage-freemusicarchive-org/tracks/xLA6bn00SGeEeP49aPxxwnpyolaECLhfhXRc5fr0.mp3';

  ngOnInit(): void {
    this.initAudio();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['trackUrl'] && changes['trackUrl'].currentValue) {
      this.audio = new Audio(this.trackUrl);
    }
  }

  ngOnDestroy(): void {
    if (this.audio) {
      this.audio.pause();
      this.audio.src = '';
      this.audio = null;
    }
  }

  private initAudio(): void {
    this.audio = new Audio(this.trackUrl);

    this.audio.addEventListener('loadeddata', () => {
      this.isLoaded = true;
      if (this.audio) {
        this.duration = this.formatTime(this.audio.duration);
      }
    });

    this.audio.addEventListener('timeupdate', () => {
      if (this.audio) {
        this.currentTime = this.formatTime(this.audio.currentTime);
        this.progressScale = this.audio.currentTime / this.audio.duration;
      }
    });

    this.audio.addEventListener('ended', () => {
      this.isPlaying = false;
      if (this.audio) {
        this.audio.currentTime = 0;
      }
    });
  }

  togglePlay(): void {
    if (!this.audio || !this.isLoaded) return;

    if (this.audio.paused) {
      this.audio.play();
      this.isPlaying = true;
    } else {
      this.audio.pause();
      this.isPlaying = false;
    }
  }

  private formatTime(time: number): string {
    const minutes = Math.floor(time / 60);
    let seconds: number | string = Math.floor(time % 60);

    if (seconds < 10) {
      seconds = `0${seconds}`;
    }

    return `${minutes}:${seconds}`;
  }

  seekAudio(event: MouseEvent): void {
    if (!this.audio || !this.isLoaded) return;

    const progressContainer = event.currentTarget as HTMLElement;
    const rect = progressContainer.getBoundingClientRect();
    const width = rect.width;

    const distanceFromRight = rect.right - event.clientX;
    const clickedRatio = distanceFromRight / width;

    const ratio = Math.max(0, Math.min(1, clickedRatio));

    this.audio.currentTime = this.audio.duration * ratio;
    this.progressScale = ratio;
    this.currentTime = this.formatTime(this.audio.currentTime);

    if (this.audio.paused) {
      this.audio.play();
      this.isPlaying = true;
    }
  }
}
