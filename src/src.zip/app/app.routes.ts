import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: '/بيت', pathMatch: 'full' },
  {
    path: 'بيت',
    loadComponent: () =>
      import('./components/home/home.component').then((c) => c.HomeComponent),
  },
  {
    path: 'taliban',
    loadComponent: () =>
      import('./components/taliban/taliban.component').then(
        (c) => c.TalibanComponent
      ),
  },
  {
    path: 'files',
    loadComponent: () =>
      import('./components/Files/files/files.component').then(
        (c) => c.FilesComponent
      ),
  },
  {
    path: 'files/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'videos/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  // {
  //   path: 'distributors/:id',
  //   loadComponent: () =>
  //     import('./components/internal-pages/internal-pages.component').then(
  //       (c) => c.InternalPagesComponent
  //     ),
  // },
  {
    path: 'editorialboard/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'videos',
    loadComponent: () =>
      import('./components/videos/videos.component').then(
        (c) => c.VideosComponent
      ),
  },
  {
    path: 'distributors',
    loadComponent: () =>
      import('./components/distributors/distributors.component').then(
        (c) => c.DistributorsComponent
      ),
  },
  {
    path: 'editorialboard',
    loadComponent: () =>
      import('./components/editorial-board/editorial-board.component').then(
        (c) => c.EditorialBoardComponent
      ),
  },
  {
    path: 'articles',
    loadComponent: () =>
      import('./components/Articles/articles/articles.component').then(
        (c) => c.ArticlesComponent
      ),
  },
  {
    path: 'summary',
    loadComponent: () =>
      import('./components/summary/summary.component').then(
        (c) => c.SummaryComponent
      ),
  },
  {
    path: 'store',
    loadComponent: () =>
      import('./components/store/store.component').then(
        (c) => c.StoreComponent
      ),
  },
  {
    path: 'highdebate',
    loadComponent: () =>
      import('./components/Articles/high-debate/high-debate.component').then(
        (c) => c.HighDebateComponent
      ),
  },
  {
    path: 'articles/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'probeinmedia/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'generals/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'philosophicals/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'audiobooks/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'interviews/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'studies/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'studiesintolerance/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'summary/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'highdebate/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'taliban/:id',
    loadComponent: () =>
      import('./components/internal-pages/internal-pages.component').then(
        (c) => c.InternalPagesComponent
      ),
  },
  {
    path: 'كتب المركز',
    loadComponent: () =>
      import('./components/books/books.component').then(
        (c) => c.BooksComponent
      ),
  },
  {
    path: 'كتب المركز/:id',
    loadComponent: () =>
      import('./components/books/books-details/books-details.component').then(
        (c) => c.BooksDetailsComponent
      ),
  },
  {
    path: 'probeinmedia',
    loadComponent: () =>
      import(
        './components/Almesbar-Center/probe-in-media/probe-in-media.component'
      ).then((c) => c.ProbeInMediaComponent),
  },
  {
    path: 'probelibrary',
    loadComponent: () =>
      import(
        './components/Almesbar-Center/probe-library/probe-library.component'
      ).then((c) => c.ProbeLibraryComponent),
  },
  {
    path: 'probelibrary/:id/:id',
    loadComponent: () =>
      import(
        './components/Almesbar-Center/probe-library/probe-library-detail/probe-library-detail.component'
      ).then((c) => c.ProbeLibraryDetailComponent),
  },
  {
    path: 'interviews',
    loadComponent: () =>
      import('./components/interviews/interviews.component').then(
        (c) => c.InterviewsComponent
      ),
    children: [
      {
        path: ':id',
        loadComponent: () =>
          import('./components/internal-pages/internal-pages.component').then(
            (c) => c.InternalPagesComponent
          ),
      },
    ],
  },
  {
    path: 'studies',
    loadComponent: () =>
      import('./components/studies/studies.component').then(
        (c) => c.StudiesComponent
      ),
  },
  {
    path: 'studiesintolerance',
    loadComponent: () =>
      import(
        './components/studies-in-tolerance/studies-in-tolerance.component'
      ).then((c) => c.StudiesInToleranceComponent),
  },
  {
    path: 'philosophicals',
    loadComponent: () =>
      import(
        './components/Concepts/philosophical/philosophical.component'
      ).then((c) => c.PhilosophicalComponent),
  },
  {
    path: 'generals',
    loadComponent: () =>
      import('./components/Concepts/general/general.component').then(
        (c) => c.GeneralComponent
      ),
  },
  {
    path: 'audiobooks',
    loadComponent: () =>
      import('./components/Files/audio-books/audio-books.component').then(
        (c) => c.AudioBooksComponent
      ),
  },
  {
    path: 'president-speech',
    loadComponent: () =>
      import(
        './components/about-us/president-speech/president-speech.component'
      ).then((c) => c.PresidentSpeechComponent),
  },
  { path: '**', redirectTo: '' },
];
