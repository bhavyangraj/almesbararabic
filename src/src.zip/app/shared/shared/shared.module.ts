import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { AppComponent } from './../../app.component';
import { SharedRoutingModule } from './shared-routing.module';
import { TalibanComponent } from './../../components/taliban/taliban.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
// import { NgxPageScrollModule } from 'ngx-page-scroll';
// import { NgxPageScrollCoreModule } from 'ngx-page-scroll-core';
import { BooksComponent } from './../../components/books/books.component';
import { ProbeInMediaComponent } from './../../components/Almesbar-Center/probe-in-media/probe-in-media.component';
import { ProbeLibraryComponent } from './../../components/Almesbar-Center/probe-library/probe-library.component';
import { ArticlesComponent } from './../../components/Articles/articles/articles.component';
import { InterviewsComponent } from './../../components/interviews/interviews.component';
import { StudiesComponent } from './../../components/studies/studies.component';

import { PhilosophicalComponent } from './../../components/Concepts/philosophical/philosophical.component';
import { GeneralComponent } from './../../components/Concepts/general/general.component';
import { AudioBooksComponent } from './../../components/Files/audio-books/audio-books.component';
import { PresidentSpeechComponent } from './../../components/about-us/president-speech/president-speech.component';
import { LoaderService } from './../../services/loader.service';
import { LoaderInterceptorService } from './../../interceptors/loader-interceptor.service';
import { MyLoaderComponent } from './../../components/my-loader/my-loader.component';
import { BooksDetailsComponent } from './../../components/books/books-details/books-details.component';
import { ProbeLibraryDetailComponent } from './../../components/Almesbar-Center/probe-library/probe-library-detail/probe-library-detail.component';
import { SelectDropDownModule } from 'ngx-select-dropdown';
@NgModule({
  declarations: [
    // TalibanComponent,
    // BooksComponent,
    // ProbeInMediaComponent,
    // ProbeLibraryComponent,
    // ArticlesComponent,
    // InterviewsComponent,
    // StudiesComponent,
    // PhilosophicalComponent,
    // GeneralComponent,
    // AudioBooksComponent,
    // PresidentSpeechComponent,
    // MyLoaderComponent,
    // BooksDetailsComponent,
    // ProbeLibraryDetailComponent,
    // BooksDetailsComponent,
    // AudioBooksComponent,
  ],
  imports: [
    CommonModule,
    SharedRoutingModule,
    FormsModule,
    NgbModule,
    ReactiveFormsModule,
    HttpClientModule,
    // NgxPageScrollModule,
    // NgxPageScrollCoreModule,
    SelectDropDownModule,
  ],
  exports: [
    // Export components that other modules might need
    // TalibanComponent,
    // BooksComponent,
    // ProbeInMediaComponent,
    // ProbeLibraryComponent,
    // ArticlesComponent,
    // InterviewsComponent,
    // StudiesComponent,
    // PhilosophicalComponent,
    // GeneralComponent,
    // AudioBooksComponent,
    // PresidentSpeechComponent,
    // MyLoaderComponent,
    // BooksDetailsComponent,
    // ProbeLibraryDetailComponent,
  ],
  providers: [
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    LoaderService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoaderInterceptorService,
      multi: true,
    },
  ],
  // bootstrap: [AppComponent],
})
export class SharedModule {}
