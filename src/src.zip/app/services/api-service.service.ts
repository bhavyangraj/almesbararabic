import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ApiServiceService {
  // basePath = 'https://almesbarnetbackend.vercel.app/api/v1/';
  // basePath = 'https://sangrah.almesbar.org/api/v1/';
  // basePath = 'https://almesbarnetbackend-production.up.railway.app/api/v1/';
  basePath = 'http://localhost:5000/api/v1/';
  // a = window.location.hostname;
  // basePath = this.a === 'localhost' ? this.basePath2 : environment.basePath;

  constructor(private router: Router, private http: HttpClient) {}

  getAll(url: any, search: string, page: number, pagesize: number) {
    if (search) {
      return this.http.get<[]>(
        this.basePath +
          url +
          '?searchTerm=' +
          encodeURIComponent(search) +
          '&page=' +
          page +
          '&limit=' +
          pagesize,
        {
          headers: { ['Content-Type']: 'application/json;charset=UTF-8' },
        }
      );
    } else {
      return this.http.get<[]>(
        this.basePath + url + '?page=' + page + '&limit=' + pagesize,
        {
          headers: { ['Content-Type']: 'application/json' },
        }
      );
    }
  }

  getFull(url: any) {
    // if (search) {
    //   return this.http.get<[]>(this.basePath + url, {
    //     headers: { ['Content-Type']: 'application/json;charset=UTF-8' },
    //   });
    // } else {
    return this.http.get<[]>(this.basePath + url + '/getall', {
      headers: { ['Content-Type']: 'application/json' },
    });
    // }
  }

  getFull2(url: any) {
    // if (search) {
    //   return this.http.get<[]>(this.basePath + url, {
    //     headers: { ['Content-Type']: 'application/json;charset=UTF-8' },
    //   });
    // } else {
    return this.http.get<[]>(this.basePath + url + '/getall', {
      headers: { ['Content-Type']: 'application/json' },
    });
    // }
  }

  getBooks(
    url: any,
    search: string,
    page: number,
    pagesize: number,
    filter: any
  ) {
    if (search || filter) {
      return this.http.get<[]>(
        this.basePath +
          url +
          '?searchTerm=' +
          encodeURIComponent(search) +
          '&page=' +
          page +
          '&limit=' +
          pagesize +
          '&filter=' +
          filter,

        {
          headers: { ['Content-Type']: 'application/json;charset=UTF-8' },
        }
      );
    } else {
      return this.http.get<[]>(
        this.basePath + url + '?page=' + page + '&limit=' + pagesize,
        {
          headers: { ['Content-Type']: 'application/json' },
        }
      );
    }
  }

  get(url: any, id: any) {
    return this.http.get<[]>(this.basePath + url + '/' + id, {
      headers: { ['Content-Type']: 'application/json' },
    });
  }

  getList(url: any) {
    return this.http.get<[]>(this.basePath + url, {
      headers: { ['Content-Type']: 'application/json' },
    });
  }
}
