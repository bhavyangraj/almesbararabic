// import { Injectable } from '@angular/core';
// import {
//   HttpResponse,
//   HttpRequest,
//   HttpHandler,
//   HttpEvent,
//   HttpInterceptor,
// } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { LoaderService } from '../services/loader.service';

// @Injectable({
//   providedIn: 'root',
// })
// export class LoaderInterceptorService implements HttpInterceptor {
//   private requests: HttpRequest<any>[] = [];

//   constructor(private loaderService: LoaderService) {}

//   removeRequest(req: HttpRequest<any>) {
//     const i = this.requests.indexOf(req);
//     if (i >= 0) {
//       this.requests.splice(i, 1);
//     }
//     this.loaderService.isLoading.next(this.requests.length > 0);
//   }

//   intercept(
//     req: HttpRequest<any>,
//     next: HttpHandler
//   ): Observable<HttpEvent<any>> {
//     this.requests.push(req);

//     console.log('No of requests--->' + this.requests.length);

//     this.loaderService.isLoading.next(true);
//     return Observable.create((observer: any) => {
//       const subscription = next.handle(req).subscribe(
//         (event) => {
//           if (event instanceof HttpResponse) {
//             this.removeRequest(req);
//             observer.next(event);
//           }
//         },
//         (err) => {
//           alert('error' + err);
//           this.removeRequest(req);
//           observer.error(err);
//         },
//         () => {
//           this.removeRequest(req);
//           observer.complete();
//         }
//       );
//       // remove request from queue when cancelled
//       return () => {
//         this.removeRequest(req);
//         subscription.unsubscribe();
//       };
//     });
//   }
// }

import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {
  HttpResponse,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap, finalize, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { LoaderService } from '../services/loader.service';

@Injectable({
  providedIn: 'root',
})
export class LoaderInterceptorService implements HttpInterceptor {
  private requests: HttpRequest<any>[] = [];

  constructor(
    private loaderService: LoaderService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  removeRequest(req: HttpRequest<any>) {
    const i = this.requests.indexOf(req);
    if (i >= 0) {
      this.requests.splice(i, 1);
    }
    this.loaderService.isLoading.next(this.requests.length > 0);
  }

  private handleError(error: HttpErrorResponse): void {
    // SSR-safe error handling
    if (isPlatformBrowser(this.platformId)) {
      // Only show alert in browser
      console.error('HTTP Error:', error);
      // Consider replacing alert with a proper notification service
      // alert('Error: ' + (error.message || 'Unknown error occurred'));
    } else {
      // Server-side logging
      console.error('SSR HTTP Error:', error);
    }
  }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // Add request to queue
    this.requests.push(req);

    // console.log('No of requests--->' + this.requests.length);
    this.loaderService.isLoading.next(true);

    return next.handle(req).pipe(
      tap((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          this.removeRequest(req);
        }
      }),
      catchError((error: HttpErrorResponse) => {
        this.handleError(error);
        this.removeRequest(req);
        return throwError(() => error);
      }),
      finalize(() => {
        // Ensure request is removed even if something goes wrong
        this.removeRequest(req);
      })
    );
  }
}
