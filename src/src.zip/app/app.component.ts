import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { FooterComponent } from './components/footer/footer.component';
import { FormsModule } from '@angular/forms';
import { MyLoaderComponent } from './components/my-loader/my-loader.component';
// import { SharedModule } from './shared/shared/shared.module';
// import { SharedRoutingModule } from './shared/shared/shared-routing.module';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    HeaderComponent,
    HomeComponent,
    FooterComponent,
    FormsModule,
    MyLoaderComponent,
    // SharedModule,
    // SharedRoutingModule,
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'almesbar_net_new';
}
