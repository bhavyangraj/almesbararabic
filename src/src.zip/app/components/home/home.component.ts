import {
  Component,
  OnInit,
  OnDestroy,
  ElementRef,
  ViewChild,
  AfterViewInit,
  Inject,
  PLATFORM_ID,
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiServiceService } from '../../services/api-service.service';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { SafeUrlPipe } from '../../pipes/safe-url.pipe';

interface SlideData {
  title: string;
  description: string;
  ctaText: string;
  ctaLink: string;
  backgroundClass: string;
}

interface ServiceData {
  icon: string;
  title: string;
  description: string;
}

interface VideoItem {
  id: string;
  title: string;
  description: string;
  duration: string;
  thumbnailUrl: string;
  category: string;
  featured?: boolean;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule, SafeUrlPipe],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('videoModal') videoModal!: ElementRef<HTMLDivElement>;
  @ViewChild('modalVideoContent')
  modalVideoContent!: ElementRef<HTMLDivElement>;

  currentSlide: number = 0;
  slideInterval: any;
  isVideoModalOpen: boolean = false;
  currentVideoTitle: string = '';
  selectedVideo: any | null = null;
  url = 'home';
  // isVideoModalOpen: boolean = false;

  // ADD THIS: Browser detection property
  private isBrowser: boolean;

  private intersectionObserver!: IntersectionObserver;

  // ADD THIS: Constructor with platform injection
  constructor(
    @Inject(PLATFORM_ID) platformId: Object,
    private apiService: ApiServiceService,
    private router: Router,
    private sanitizer: DomSanitizer
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
  }

  getThumbnailUrl(url: string): string {
    if (!url) return '';

    // Extract YouTube video ID
    const videoId = this.extractYouTubeId(url);

    // Return high-quality thumbnail
    return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
  }

  extractYouTubeId(url: string): string | null {
    const regex =
      /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&]+)/;
    const match = url.match(regex);
    return match ? match[1] : null;
  }

  tabs = [
    { id: 'probemedia', title: 'Probe In Media' },
    { id: 'articles', title: 'Articles' },
    { id: 'studies', title: 'Studies' },
    { id: 'summary', title: 'Summary' },
  ];

  selectedTab: any = 'probemedia';
  trackByBookId(index: number, book: any): number {
    return book.id;
  }

  currentBookIndex = 0;

  nextBook() {
    this.currentBookIndex = (this.currentBookIndex + 1) % this.books2.length;
  }

  prevBook() {
    this.currentBookIndex =
      (this.currentBookIndex - 1 + this.books2.length) % this.books2.length;
  }

  goToBook(index: number) {
    this.currentBookIndex = index;
  }

  selectTab(tabId: string) {
    this.selectedTab = tabId;
  }

  getPostsForSelectedTab() {
    if (this.selectedTab == 'probemedia') {
      return this.probemedia;
    } else if (this.selectedTab == 'articles') {
      return this.articles;
    } else if (this.selectedTab == 'summary') {
      return this.summary;
    } else {
      return this.studies;
    }
  }

  slides2: any[] = [];
  articles: any[] = [];
  books2: any[] = [];
  probemedia: any[] = [];
  studies: any[] = [];
  summary: any[] = [];
  videos2: any[] = [];

  // videos: VideoData[] = [
  //   {
  //     id: 'demo1',
  //     title: 'Modern Web Design Trends',
  //     description:
  //       'Discover the latest trends in web design and how to implement them in your projects for maximum impact.',
  //     duration: '3:45',
  //     thumbnailGradient: 'linear-gradient(45deg, #667eea, #764ba2)',
  //   },
  //   {
  //     id: 'demo2',
  //     title: 'JavaScript Fundamentals',
  //     description:
  //       'Master the core concepts of JavaScript programming with practical examples and real-world applications.',
  //     duration: '5:22',
  //     thumbnailGradient: 'linear-gradient(45deg, #f093fb, #f5576c)',
  //   },
  //   {
  //     id: 'demo3',
  //     title: 'Responsive Design Principles',
  //     description:
  //       'Learn how to create websites that look perfect on any device with responsive design techniques.',
  //     duration: '7:18',
  //     thumbnailGradient: 'linear-gradient(45deg, #4facfe, #00f2fe)',
  //   },
  //   {
  //     id: 'demo4',
  //     title: 'CSS Animation Mastery',
  //     description:
  //       'Create stunning animations and transitions that bring your web designs to life with CSS.',
  //     duration: '4:33',
  //     thumbnailGradient: 'linear-gradient(45deg, #a8edea, #fed6e3)',
  //   },
  //   {
  //     id: 'demo5',
  //     title: 'User Experience Design',
  //     description:
  //       'Understand the principles of UX design and how to create intuitive user interfaces.',
  //     duration: '6:07',
  //     thumbnailGradient: 'linear-gradient(45deg, #ffecd2, #fcb69f)',
  //   },
  //   {
  //     id: 'demo6',
  //     title: 'Performance Optimization',
  //     description:
  //       'Optimize your websites for speed and performance with advanced techniques and tools.',
  //     duration: '8:41',
  //     thumbnailGradient: 'linear-gradient(45deg, #a18cd1, #fbc2eb)',
  //   },
  // ];

  ngOnInit(): void {
    if (this.isBrowser) {
      this.startSlideshow();
      this.setupScrollAnimations();
      this.setupScrollNavbar();
      // this.get('mb220');
      // this.get('mb219');
      // this.get('mb218');
      // this.get('mb221');
      this.get();
      // if (this.videos2.length > 0) {

      // }
    }
  }

  get() {
    this.apiService.getFull2(this.url).subscribe(
      (data: any) => {
        console.log(data);
        // this.slides2.push(data.data[0]);
        this.slides2 = data.slider;
        this.articles = data.articles;
        this.studies = data.studies;
        this.summary = data.summary;
        this.books2 = data.books;
        this.videos2 = data.videos;
        this.selectedVideo = this.videos2[0];
        this.probemedia = data.probemedia;
        console.log(this.slides2);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  ngAfterViewInit(): void {
    if (this.isBrowser) {
      this.setupKeyboardListeners();
      setInterval(() => this.nextBook(), 6000);
    }
  }

  ngOnDestroy(): void {
    if (this.isBrowser) {
      if (this.slideInterval) {
        clearInterval(this.slideInterval);
      }
      if (this.intersectionObserver) {
        this.intersectionObserver.disconnect();
      }
    }
  }

  // Slider Methods
  startSlideshow(): void {
    this.slideInterval = setInterval(() => {
      this.nextSlide();
    }, 5000);
  }

  showSlide(index: number): void {
    if (index >= 0 && index < this.slides2.length) {
      this.currentSlide = index;
    }
  }

  nextSlide(): void {
    this.currentSlide = (this.currentSlide + 1) % this.slides2.length;
  }

  onDotClick(index: number): void {
    this.showSlide(index);
    // Reset interval
    if (this.slideInterval) {
      clearInterval(this.slideInterval);
      this.startSlideshow();
    }
  }

  // Navigation Methods
  scrollToSection(sectionId: string): void {
    if (!this.isBrowser) return;

    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }
  }

  gotoPage(post: any) {
    if (this.selectedTab == 'probemedia') {
      this.router.navigate(['/probeinmedia/' + post._id]);
    } else if (this.selectedTab == 'articles') {
      this.router.navigate(['/articles/' + post._id]);
    } else if (this.selectedTab == 'summary') {
      this.router.navigate(['/summary/' + post._id]);
    } else {
      this.router.navigate(['/studies/' + post._id]);
    }
  }

  gotoBook2(post: any) {
    this.router.navigate(['/كتب المركز/' + post.id]);
  }

  gotoVideo(post: any) {
    this.router.navigate(['/videos/' + post._id]);
  }

  // // Video Methods
  // openVideoModal(video: VideoData): void {
  //   if (!this.isBrowser) return;

  //   this.currentVideoTitle = video.title;
  //   this.isVideoModalOpen = true;

  //   if (typeof document !== 'undefined') {
  //     document.body.style.overflow = 'hidden';
  //   }

  //   // Update modal content
  //   if (this.modalVideoContent) {
  //     this.modalVideoContent.nativeElement.innerHTML = `
  //       <div style="text-align: center;">
  //         <h3 style="margin-bottom: 2rem; color: #ff6b6b;">${video.title}</h3>
  //         <p style="color: #ccc;">This is a demo video player.</p>
  //         <p style="color: #ccc; margin-top: 1rem;">In a real implementation, you would integrate with a video service like YouTube, Vimeo, or host your own videos.</p>
  //       </div>
  //     `;
  //   }
  // }

  // closeVideoModal(): void {
  //   this.isVideoModalOpen = false;

  //   if (this.isBrowser && typeof document !== 'undefined') {
  //     document.body.style.overflow = 'auto';
  //   }
  // }

  onModalBackdropClick(event: MouseEvent): void {
    if (event.target === this.videoModal?.nativeElement) {
      this.closeVideoModal();
    }
  }

  // Private Methods
  private setupScrollAnimations(): void {
    if (!this.isBrowser || typeof IntersectionObserver === 'undefined') {
      // Fallback for non-browser environments or older browsers
      setTimeout(() => {
        const fadeElements = document.querySelectorAll('.fade-in');
        fadeElements.forEach((el: Element) => {
          el.classList.add('visible');
        });
      }, 100);
      return;
    }

    const observerOptions: IntersectionObserverInit = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px',
    };

    this.intersectionObserver = new IntersectionObserver(
      (entries: IntersectionObserverEntry[]) => {
        entries.forEach((entry: IntersectionObserverEntry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      observerOptions
    );

    // Observe elements after view init
    setTimeout(() => {
      const fadeElements = document.querySelectorAll('.fade-in');
      fadeElements.forEach((el: Element) => {
        this.intersectionObserver.observe(el);
      });
    }, 100);
  }

  private setupScrollNavbar(): void {
    if (!this.isBrowser || typeof window === 'undefined') return;

    window.addEventListener('scroll', () => {
      const navbar = document.querySelector('.navbar') as HTMLElement;
      if (navbar) {
        if (window.scrollY > 100) {
          navbar.style.background = 'rgba(0, 0, 0, 0.95)';
        } else {
          navbar.style.background = 'rgba(0, 0, 0, 0.9)';
        }
      }
    });
  }

  private setupKeyboardListeners(): void {
    if (!this.isBrowser || typeof document === 'undefined') return;

    document.addEventListener('keydown', (event: KeyboardEvent) => {
      if (event.key === 'Escape' && this.isVideoModalOpen) {
        this.closeVideoModal();
      }
    });
  }

  // // Utility Methods
  // trackByVideoId(index: number, video: VideoData): string {
  //   return video.id;
  // }

  trackByServiceTitle(index: number, service: ServiceData): string {
    return service.title;
  }

  trackBySlideIndex(index: number, slide: SlideData): number {
    return index;
  }

  selectVideo(video: VideoItem): void {
    this.selectedVideo = video;
  }

  closeVideoModal(): void {
    this.isVideoModalOpen = false;

    if (this.isBrowser && typeof document !== 'undefined') {
      document.body.style.overflow = 'auto';
    }
  }

  // onModalBackdropClick(event: MouseEvent): void {
  //   const target = event.target as HTMLElement;
  //   if (target.classList.contains('video-modal')) {
  //     this.closeVideoModal();
  //   }
  // }

  trackByVideoId(index: number, video: VideoItem): string {
    return video.id;
  }
}
