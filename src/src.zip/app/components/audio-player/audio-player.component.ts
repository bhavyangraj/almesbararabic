import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
  Input,
} from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-audio-player',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './audio-player.component.html',
  styleUrl: './audio-player.component.css',
})
export class AudioPlayerComponent {
  @ViewChild('audioElement') audioElement!: ElementRef<HTMLAudioElement>;

  // 🎵 PUT YOUR MP3 URL HERE 🎵
  @Input() audioUrl =
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'; // ← Change this to your MP3 URL
  trackTitle = 'Your Song Title'; // ← Change the title
  trackArtist = 'Artist Name'; // ← Change the artist name

  isPlaying = false;
  currentTime = 0;
  duration = 0;
  volume = 0.7;
  isMuted = false;
  progressPercent = 0;

  ngOnInit() {
    setTimeout(() => {
      if (this.audioElement?.nativeElement) {
        this.audioElement.nativeElement.volume = this.volume;
      }
    });
  }

  ngOnDestroy() {
    if (this.audioElement?.nativeElement) {
      this.audioElement.nativeElement.pause();
    }
  }

  togglePlay() {
    const audio = this.audioElement.nativeElement;
    if (this.isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
  }

  onPlay() {
    this.isPlaying = true;
  }

  onPause() {
    this.isPlaying = false;
  }

  onTimeUpdate() {
    const audio = this.audioElement.nativeElement;
    this.currentTime = audio.currentTime;
    if (this.duration > 0) {
      this.progressPercent = (this.currentTime / this.duration) * 100;
    }
  }

  onLoadedMetadata() {
    const audio = this.audioElement.nativeElement;
    this.duration = audio.duration;
  }

  seek(event: MouseEvent) {
    const progressBar = event.currentTarget as HTMLElement;
    const rect = progressBar.getBoundingClientRect();
    const percent = (event.clientX - rect.left) / rect.width;
    const audio = this.audioElement.nativeElement;
    audio.currentTime = percent * this.duration;
  }

  rewind() {
    const audio = this.audioElement.nativeElement;
    audio.currentTime = Math.max(0, audio.currentTime - 10);
  }

  forward() {
    const audio = this.audioElement.nativeElement;
    audio.currentTime = Math.min(this.duration, audio.currentTime + 10);
  }

  setVolume(event: Event) {
    const input = event.target as HTMLInputElement;
    this.volume = parseFloat(input.value) / 100;
    const audio = this.audioElement.nativeElement;
    audio.volume = this.volume;
    if (this.volume > 0) {
      this.isMuted = false;
    }
  }

  toggleMute() {
    const audio = this.audioElement.nativeElement;
    this.isMuted = !this.isMuted;
    audio.muted = this.isMuted;
  }

  formatTime(seconds: number): string {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }
}
