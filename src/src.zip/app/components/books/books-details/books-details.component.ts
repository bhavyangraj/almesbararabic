import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  HostListener,
  OnInit,
  ViewChild,
} from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { ApiServiceService } from '../../../services/api-service.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { AudioPlayerComponent } from '../../audio-player/audio-player.component';
import { AudioPlayerMinComponent } from '../../audio-player-min/audio-player-min.component';
import { DomSanitizer } from '@angular/platform-browser';
// import { PdfViewerComponent } from '../../pdf-viewer/pdf-viewer.component';

@Component({
  selector: 'app-books-details',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NgbModule,
    AudioPlayerMinComponent,
    AudioPlayerComponent,
    // PdfViewerComponent,
  ],
  templateUrl: './books-details.component.html',
  styleUrls: ['./books-details.component.css'],
})
export class BooksDetailsComponent implements OnInit {
  downloadUrl!: string;
  constructor(
    private apiService: ApiServiceService,
    private router: Router,
    private http: HttpClient,
    private sanitizer: DomSanitizer
  ) {
    let url = router.url.split('/');
    this.id = url[2];
    // console.log(this.id);
    this.number = this.id.split('mb');
    // console.log(this.number, this.number[1]);
    this.audio = `assets/audio/${this.number[1]}.mp3`;
    // console.log(this.number);
  }

  books: any = {};
  url = 'booksbyId';
  id: any;
  number: any;
  fileExists: { [key: string]: boolean } = {};
  fileExists2: { [key: string]: boolean } = {};
  fileExists3: { [key: string]: boolean } = {};
  fileExists4: { [key: string]: boolean } = {};
  check: any;
  fontSize = 16;
  audio: any;
  items = [
    { label: 'Traditional Arabic', value: 'YourCustomFontName2' },
    {
      label: 'Noto Kufi Arabic',
      value: 'Noto Kufi Arabic,ui-sans-serif,Helvetica Neue,sans-serif',
    },
  ];

  // Preselect one item
  selectedItem = 'YourCustomFontName2';

  ngOnInit(): void {
    // if (localStorage.getItem('id')) {
    //   this.id = localStorage.getItem('id');
    // }
    this.get();
    // this.check = this.checkFileExists(this.number[1]);
    // console.log(this.check);
    this.checkFileExists(this.number[1]);
    this.checkFileExists2(this.number[1]);
    this.checkFileExists3(this.number[1]);
    this.checkFileExists4(this.number[1]);
  }

  checkFileExists(fileName: string): void {
    // const filePath = `assets/TOC/${fileName}.pdf`;
    // // console.log(filePath);
    // this.http.head(filePath, { observe: 'response' }).subscribe({
    //   next: (response) => {
    //     this.fileExists[fileName] = response.status === 200;
    //     // console.log(this.fileExists[fileName]);
    //   },
    //   error: () => {
    //     this.fileExists[fileName] = false;
    //     // console.log(this.fileExists[fileName]);
    //   },
    // });
    const filePath = `assets/TOC/${fileName}.pdf`;

    this.http.get(filePath, { responseType: 'blob' }).subscribe({
      next: (blob) => {
        const isPdf = blob.type === 'application/pdf';
        this.fileExists[fileName] = isPdf;
        // console.log(fileName, isPdf, blob.type);
      },
      error: () => {
        this.fileExists[fileName] = false;
        // console.log(fileName, false, 'From Error');
      },
    });
  }

  checkFileExists4(fileName: string): void {
    // const filePath = `assets/intro_of_books/${fileName}.pdf`;
    // // console.log(filePath);
    // this.http.head(filePath, { observe: 'response' }).subscribe({
    //   next: (response) => {
    //     this.fileExists4[fileName] = response.status === 200;
    //     // console.log(this.fileExists[fileName]);
    //   },
    //   error: () => {
    //     this.fileExists4[fileName] = false;
    //     // console.log(this.fileExists[fileName]);
    //   },
    // });
    const filePath = `assets/intro_of_books/${fileName}.pdf`;

    this.http.get(filePath, { responseType: 'blob' }).subscribe({
      next: (blob) => {
        const isPdf = blob.type === 'application/pdf';
        this.fileExists4[fileName] = isPdf;
        // console.log(fileName, isPdf, blob.type);
      },
      error: () => {
        this.fileExists4[fileName] = false;
        // console.log(fileName, false, 'From Error');
      },
    });
  }

  checkFileExists2(fileName: string): void {
    // const filePath = `assets/front/front${fileName}.jpg`;
    // // console.log(filePath);
    // this.http.head(filePath, { observe: 'response' }).subscribe({
    //   next: (response) => {
    //     this.fileExists2[fileName] = response.status === 200;
    //     // console.log(this.fileExists[fileName]);
    //   },
    //   error: () => {
    //     this.fileExists2[fileName] = false;
    //     // console.log(this.fileExists[fileName]);
    //   },
    // });
    const img = new Image();
    img.onload = () => {
      this.fileExists2[fileName] = true;
      // console.log(fileName, true);
    };
    img.onerror = () => {
      this.fileExists2[fileName] = false;
      // console.log(fileName, false);
    };
    img.src = `assets/front/front${fileName}.jpg`;
  }

  checkFileExists3(fileName: string): void {
    // const filePath = `assets/back/back${fileName}.jpg`;
    // console.log(filePath);
    // this.http.head(filePath, { observe: 'response' }).subscribe({
    //   next: (response) => {
    //     console.log(response, 'From Response');
    //     this.fileExists3[fileName] = response.status === 200;
    //     console.log(this.fileExists3[fileName]);
    //   },
    //   error: () => {
    //     console.log('From Error');
    //     this.fileExists3[fileName] = false;
    //     console.log(this.fileExists3[fileName]);
    //   },
    // });
    const img = new Image();
    img.onload = () => {
      this.fileExists3[fileName] = true;
      // console.log(fileName, true);/
    };
    img.onerror = () => {
      this.fileExists3[fileName] = false;
      // console.log(fileName, false);
    };
    img.src = `assets/back/back${fileName}.jpg`;
  }

  get() {
    this.apiService.get(this.url, this.id).subscribe(
      (data: any) => {
        // console.log(data);
        this.books = data.data[0];
        this.books.introduction = this.sanitizer.bypassSecurityTrustHtml(
          data.data[0].introduction
        );
        // console.log(this.books);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  changeFontSize(action: 'smaller' | 'bigger') {
    if (action === 'smaller' && this.fontSize > 10) {
      this.fontSize -= 2;
    } else if (action === 'bigger' && this.fontSize < 40) {
      this.fontSize += 2;
    }
  }

  printContent(data: any) {
    const printWindow = window.open('', '', 'width=800,height=600');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Print</title>
            <style>
              body { font-size: ${this.fontSize}px; line-height: 1.5; }
            </style>
          </head>
          <body>
            ${data}
          </body>
        </html>
      `);
      printWindow.document.close();
      setTimeout(() => {
        printWindow.print();
      }, 1000);
    }
  }

  onContentClick(event: Event) {
    const target = event.target as HTMLElement;
    if (target.tagName.toLowerCase() === 'a') {
      const href = target.getAttribute('href');
      if (href && href.startsWith('#')) {
        event.preventDefault();
        const el = document.querySelector(href);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }
    }
  }
}
