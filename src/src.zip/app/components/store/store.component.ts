import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {
  Component,
  HostListener,
  OnInit,
  ViewEncapsulation,
} from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ApiServiceService } from '../../services/api-service.service';

import { SelectDropDownModule } from 'ngx-select-dropdown';

@Component({
  selector: 'app-store',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NgbModule,
    SelectDropDownModule,
  ],
  templateUrl: './store.component.html',
  styleUrl: './store.component.css',
})
export class StoreComponent {
  books: any[] = [];
  dropDownList: any[] = [];
  page = 1;
  pageSize = 50;
  pageSizes = [15, 30, 50];
  size = 0;
  public isActive: any = true;
  search = '';
  url = 'shop';
  url2 = 'dropdown';
  closeResult: string = '';
  data: any;
  filter: any;
  config = {
    search: false,
    noResultsFound: 'No results found!',
    height: '300px',
    customComparator: (a: any, b: any): number => {
      return a.value - b.value;
    },
    // searchOnKey: 'publishYear',
    placeholder: 'Select Year',
  };
  dataModel: any;
  loading = false;
  totalPages: any;

  constructor(
    private apiService: ApiServiceService,
    private router: Router,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    // if (localStorage.getItem('pageBook')) {
    //   this.page = Number(localStorage.getItem('pageBook'));
    this.get();
    this.getDropDown();
    // } else {
    //   this.get();
    // }
    // this.dropDownList.sort((a, b) => b.value - a.value);
  }

  get() {
    if (this.loading || this.page > this.totalPages) return; // avoid duplicate requests
    this.loading = true;

    this.apiService
      .getBooks(
        this.url,
        this.search,
        this.page,
        this.pageSize,
        this.filter || ''
      )
      .subscribe(
        (data: any) => {
          this.books = [...this.books, ...data.data];
          this.page++;
          this.totalPages = data.totalPages;
          this.loading = false;
          console.log(this.books);
          //for (let i = 0; i < 25; i++) {
          //this.books.push(this.books[0]);
          // }
          this.size = data.count;
        },
        (error) => {
          console.log(error);
        }
      );
  }

  handlePageSizeChange(): void {
    this.page = 1;
    this.ngOnInit();
  }

  openScrollableContent(longContent: any, book: any) {
    this.data = book;
    this.modalService.open(longContent, { scrollable: true, size: 'xl' });
  }

  gotoDetailPage(id: any, id2: any) {
    localStorage.setItem('id', id2);
    // let link = window.location.href + '/' + id;
    // this.router.navigate([]).then((result) => {
    //   window.open(link);
    // });
    this.router.navigate(['/كتب المركز/' + id]);
  }

  pageChange(event: any) {
    console.log(event);
    this.page = event;
    window.scrollTo(0, 0);
    // localStorage.setItem('pageBook', JSON.stringify(this.page));
    this.get();
  }

  getDropDown() {
    this.apiService.getList(this.url2).subscribe(
      (data: any) => {
        console.log(data);
        this.dropDownList = data.data;
        this.dropDownList = this.dropDownList.sort((a, b) => b - a);
        console.log(this.dropDownList);

        // this.dropDownList.sort().reverse();
        //for (let i = 0; i < 25; i++) {
        //this.books.push(this.books[0]);
        // }
        // this.size = data.count;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  selectionChanged(event: any) {
    this.books = [];
    this.page = 1;
    this.filter = event.value;
    this.ngOnInit();
  }

  backToTop() {
    window.scrollTo(0, 0);
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const pos =
      (document.documentElement.scrollTop || document.body.scrollTop) +
      window.innerHeight;
    const max = document.documentElement.scrollHeight;

    if (pos >= max - 400) {
      // 50px before reaching bottom
      this.get();
    }
  }
}
