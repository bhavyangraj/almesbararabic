import { Component, HostListener, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // 👈 needed for ngIf, ngFor, etc.
import { FormsModule } from '@angular/forms'; // 👈 if you're using [(ngModel)]
import { Router, RouterModule } from '@angular/router'; // 👈 if template uses routerLink
import { ApiServiceService } from '../../services/api-service.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SocialLinksComponent } from '../social-links/social-links.component';

@Component({
  selector: 'app-studies-in-tolerance',
  standalone: true, // 👈 standalone enabled
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NgbModule,
    SocialLinksComponent,
  ],
  templateUrl: './studies-in-tolerance.component.html',
  styleUrls: ['./studies-in-tolerance.component.css'],
})
export class StudiesInToleranceComponent implements OnInit {
  studiesintolerances: any[] = [];
  page = 1;
  pageSize = 10;
  pageSizes = [10, 50, 100, 200, 300, 400];
  size = 0;
  public isActive: any = true;
  search = '';
  url = 'studiesintolerance';
  hideImages = true;
  loading = false;
  totalPages: any;

  constructor(private apiService: ApiServiceService, private router: Router) {}

  ngOnInit(): void {
    this.get();
  }

  get() {
    if (this.loading || this.page > this.totalPages) return; // avoid duplicate requests
    this.loading = true;
    this.apiService
      .getAll(this.url, this.search, this.page, this.pageSize)
      .subscribe(
        (data: any) => {
          this.studiesintolerances = [
            ...this.studiesintolerances,
            ...data.data,
          ];
          this.page++;
          this.totalPages = data.totalPages;
          this.loading = false;
          this.size = data.count;
        },
        (error) => {
          console.log(error);
        }
      );
  }

  handlePageSizeChange(): void {
    this.page = 1;
    this.get();
  }

  pageChange(event: any) {
    this.page = event;
    window.scrollTo(0, 0);
    this.get();
  }
  isLongText(text: any): boolean {
    return text && text.length > 300;
  }

  openInNewTab(id: string) {
    // Assuming you have a study details route like /study/:id
    this.router.navigate(['/studiesintolerance/' + id]);
  }

  getUrl(data: any) {
    return window.location.href + '/' + data;
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const pos =
      (document.documentElement.scrollTop || document.body.scrollTop) +
      window.innerHeight;
    const max = document.documentElement.scrollHeight;

    if (pos >= max - 400) {
      // 50px before reaching bottom
      this.get();
    }
  }
}
