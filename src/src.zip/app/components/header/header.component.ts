import { CommonModule } from '@angular/common';
import { Component, Inject, AfterViewInit, PLATFORM_ID } from '@angular/core';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import {
  RouterModule,
  RouterOutlet,
  NavigationEnd,
  Router,
} from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {
  show = false;
  show2 = false;
  show3 = false;
  show4 = false;
  navbutton = false;

  constructor(
    private router: Router,
    @Inject(DOCUMENT) private document: Document,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    // Listen for route changes
    this.router.events.subscribe((event) => {
      if (
        event instanceof NavigationEnd &&
        isPlatformBrowser(this.platformId)
      ) {
        this.closeMenu();
      }
    });
  }

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.closeMenu();
    }
  }

  closeMenu() {
    const checkbox = document.getElementById(
      'navi-toggle'
    ) as HTMLInputElement | null;
    if (checkbox) {
      checkbox.checked = false;
      this.navbutton = false;
    }
  }
}
