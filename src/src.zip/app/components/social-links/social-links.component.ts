import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-social-links',
  standalone: true,
  imports: [],
  templateUrl: './social-links.component.html',
  styleUrl: './social-links.component.css',
})
export class SocialLinksComponent {
  @Input() shareUrl?: string;

  // Get the URL to share (custom or current page)
  private getShareUrl(): string {
    return this.shareUrl || window.location.href;
  }

  // Facebook Share
  onFacebookClick(): void {
    const url = encodeURIComponent(this.getShareUrl());
    const shareLink = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
    this.openPopup(shareLink);
  }

  // Twitter Share
  onTwitterClick(): void {
    const url = encodeURIComponent(this.getShareUrl());
    // const text = encodeURIComponent(this.shareTitle);
    // &text=${text}
    const shareLink = `https://twitter.com/intent/tweet?url=${url}`;
    this.openPopup(shareLink);
  }

  // LinkedIn Share
  onLinkedInClick(): void {
    const url = encodeURIComponent(this.getShareUrl());
    const shareLink = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
    this.openPopup(shareLink);
  }

  // WhatsApp Share
  onWhatsAppClick(): void {
    const url = encodeURIComponent(this.getShareUrl());
    const shareLink = `https://wa.me/?text=${url}`;
    this.openPopup(shareLink);
  }

  // Generic Share (uses Web Share API or copies to clipboard)
  async onShareClick(): Promise<void> {
    const url = this.getShareUrl();

    if (navigator.share) {
      try {
        await navigator.share({
          // title: this.shareTitle,
          url: url,
        });
        console.log('Content shared successfully');
      } catch (err) {
        console.log('Share cancelled or failed:', err);
      }
    } else {
      // Fallback: Copy to clipboard
      this.copyToClipboard(url);
    }
  }

  // Helper method to open popup window
  private openPopup(url: string): void {
    const width = 600;
    const height = 400;
    const left = (window.innerWidth - width) / 2;
    const top = (window.innerHeight - height) / 2;

    window.open(
      url,
      'share',
      `width=${width},height=${height},left=${left},top=${top},toolbar=0,status=0`
    );
  }

  // Helper method to copy URL to clipboard
  private copyToClipboard(text: string): void {
    if (navigator.clipboard) {
      navigator.clipboard
        .writeText(text)
        .then(() => {
          alert('Link copied to clipboard!');
        })
        .catch((err) => {
          console.error('Failed to copy:', err);
        });
    } else {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      alert('Link copied to clipboard!');
    }
  }
}
