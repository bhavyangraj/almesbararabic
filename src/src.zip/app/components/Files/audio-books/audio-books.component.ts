import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Component, HostListener, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { ApiServiceService } from '../../../services/api-service.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SocialLinksComponent } from '../../social-links/social-links.component';
import { AudioPlayerComponent } from '../../audio-player/audio-player.component';

@Component({
  selector: 'app-audio-books',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NgbModule,
    SocialLinksComponent,
    AudioPlayerComponent,
  ],
  templateUrl: './audio-books.component.html',
  styleUrls: ['./audio-books.component.css'],
})
export class AudioBooksComponent implements OnInit {
  audiobooks: any[] = [];
  page = 1;
  pageSize = 10;
  pageSizes = [10, 50, 100, 200, 300, 400];
  size = 0;
  public isActive: any = true;
  search = '';
  url = 'audiobooks';
  hideImages = true;
  loading = false;
  totalPages: any;

  constructor(private apiService: ApiServiceService, private router: Router) {}

  ngOnInit(): void {
    this.get();
  }

  get() {
    if (this.loading || this.page > this.totalPages) return; // avoid duplicate requests
    this.loading = true;
    this.apiService
      .getAll(this.url, this.search, this.page, this.pageSize)
      .subscribe(
        (data: any) => {
          this.audiobooks = [...this.audiobooks, ...data.data];
          this.page++;
          this.totalPages = data.totalPages;
          this.loading = false;
          this.size = data.count;
        },
        (error) => {
          console.log(error);
        }
      );
  }

  handlePageSizeChange(): void {
    this.page = 1;
    this.ngOnInit();
  }

  pageChange(event: any) {
    console.log(event);
    this.page = event;
    window.scrollTo(0, 0);
    this.get();
  }
  isLongText(text: any): boolean {
    return text && text.length > 300;
  }

  openInNewTab(id: string) {
    // Assuming you have a study details route like /study/:id
    this.router.navigate(['/audiobooks/' + id]);
  }

  getUrl(data: any) {
    return window.location.href + '/' + data;
  }
  @HostListener('window:scroll', [])
  onWindowScroll() {
    const pos =
      (document.documentElement.scrollTop || document.body.scrollTop) +
      window.innerHeight;
    const max = document.documentElement.scrollHeight;

    if (pos >= max - 400) {
      // 50px before reaching bottom
      this.get();
    }
  }
}
