import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ApiServiceService } from './../../../../services/api-service.service';

@Component({
  selector: 'app-probe-library-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, NgbModule],
  templateUrl: './probe-library-detail.component.html',
  styleUrls: ['./probe-library-detail.component.css'],
})
export class ProbeLibraryDetailComponent implements OnInit {
  constructor(private apiService: ApiServiceService, private router: Router) {
    let url = router.url.split('/');
    this.id = url[3];
  }

  books: any = {};
  url = 'probelibrary';
  id: any;
  fontSize = 16;
  items = [
    { label: 'Traditional Arabic', value: 'YourCustomFontName2' },
    {
      label: 'Noto Kufi Arabic',
      value: 'Noto Kufi Arabic,ui-sans-serif,Helvetica Neue,sans-serif',
    },
  ];

  // Preselect one item
  selectedItem = 'YourCustomFontName2';

  ngOnInit(): void {
    // if (localStorage.getItem('id')) {
    //   this.id = localStorage.getItem('id');
    // }
    this.get();
  }

  get() {
    this.apiService.get(this.url, this.id).subscribe(
      (data: any) => {
        console.log(data);
        this.books = data.data;
      },
      (error: any) => {
        console.log(error);
      }
    );
  }
  onContentClick(event: Event) {
    const target = event.target as HTMLElement;
    if (target.tagName.toLowerCase() === 'a') {
      const href = target.getAttribute('href');
      if (href && href.startsWith('#')) {
        event.preventDefault();
        const el = document.querySelector(href);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }
    }
  }

  printContent(data: any) {
    const printWindow = window.open('', '', 'width=800,height=600');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Print</title>
            <style>
              body { font-size: ${this.fontSize}px; line-height: 1.5; }
            </style>
          </head>
          <body>
            ${data}
          </body>
        </html>
      `);
      printWindow.document.close();
      setTimeout(() => {
        printWindow.print();
      }, 1000);
    }
  }

  changeFontSize(action: 'smaller' | 'bigger') {
    if (action === 'smaller' && this.fontSize > 10) {
      this.fontSize -= 2;
    } else if (action === 'bigger' && this.fontSize < 40) {
      this.fontSize += 2;
    }
  }
}
