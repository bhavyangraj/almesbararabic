import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import { ApiServiceService } from '../../services/api-service.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { SafeUrlPipe } from '../../pipes/safe-url.pipe';

@Component({
  selector: 'app-internal-pages',
  standalone: true,
  imports: [CommonModule, FormsModule, SafeUrlPipe],
  templateUrl: './internal-pages.component.html',
  styleUrl: './internal-pages.component.css',
})
export class InternalPagesComponent implements OnInit, AfterViewInit {
  @ViewChild('scrollContainer', { static: false }) scrollContainer!: ElementRef;
  books: any = {};
  studies: any[] = [];
  url: any;
  id: any;
  id2: any;
  private isPaused = false;
  fontSize = 16;
  items = [
    { label: 'Traditional Arabic', value: 'YourCustomFontName2' },
    {
      label: 'Noto Kufi Arabic',
      value: 'Noto Kufi Arabic,ui-sans-serif,Helvetica Neue,sans-serif',
    },
  ];

  // Preselect one item
  selectedItem = 'YourCustomFontName2';

  private scrollAnimationId: any;

  constructor(
    private apiService: ApiServiceService,
    private router: Router,
    private http: HttpClient,
    private sanitizer: DomSanitizer,
    private elementRef: ElementRef
  ) {
    let url = router.url.split('/');
    console.log(url);
    this.id = url[1];
    this.id2 = url[2];
    if (this.id == 'articles') {
      this.url = 'articles';
    } else if (this.id == 'generals') {
      this.url = 'generals';
    } else if (this.id == 'philosophicals') {
      this.url = 'philosophicals';
    } else if (this.id == 'audiobooks') {
      this.url = 'audiobooks';
    } else if (this.id == 'interviews') {
      this.url = 'interviews';
    } else if (this.id == 'studies') {
      this.url = 'studies';
    } else if (this.id == 'studiesintolerance') {
      this.url = 'studiesintolerance';
    } else if (this.id == 'taliban') {
      this.url = 'taliban';
    } else if (this.id == 'probeinmedia') {
      this.url = 'probeinmedia';
    } else if (this.id == 'files') {
      this.url = 'files';
    } else if (this.id == 'videos') {
      this.url = 'videos';
    } else if (this.id == 'editorialboard') {
      this.url = 'authors';
    } else if (this.id == 'distributors') {
      this.url = 'distributors';
    } else if (this.id == 'highdebate') {
      this.url = 'highdebate';
    } else if (this.id == 'summary') {
      this.url = 'summary';
    }
    // console.log(this.id);
    // this.number = this.id.split('mb');
    // console.log(this.number);
  }

  ngOnInit(): void {
    this.get();
    console.log(this.id);
    if (
      this.id != 'editorialboard' &&
      this.id != 'distributors' &&
      this.id != 'videos'
    ) {
      this.getFull();
    }
  }

  ngAfterViewInit(): void {
    this.startAutoScroll();
  }

  byPassId(htmlString: string): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(htmlString);
  }

  get() {
    this.apiService.get(this.url, this.id2).subscribe(
      (data: any) => {
        // console.log(data);
        this.books = data.data;
        this.books.description = this.sanitizer.bypassSecurityTrustHtml(
          data.data.description
        );
        console.log(this.books.length);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  getFull() {
    this.apiService.getFull(this.url).subscribe(
      (data: any) => {
        console.log(data);
        this.studies = data.data;
        this.studies = this.studies.filter((item) => item.id != this.books.id);
        // console.log(this.books.length);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  getSantizeUrl(url: string) {
    url = this.getYouTubeEmbedUrl(url);
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  getYouTubeEmbedUrl(url: string): string {
    let videoId: string | null = null;

    if (url.includes('youtu.be')) {
      videoId = url.split('youtu.be/')[1];
    } else if (url.includes('youtube.com/watch?v=')) {
      const params = new URL(url).searchParams;
      videoId = params.get('v');
    }

    return videoId ? `https://www.youtube.com/embed/${videoId}` : '';
  }

  toggleReadMore(study: any) {
    study.showFull = !study.showFull;
  }

  startAutoScroll() {
    setTimeout(() => {
      const container = this.scrollContainer.nativeElement;

      // this.scrollInterval = setInterval(() => {
      //   container.scrollLeft += 1; // move scroll right → left

      //   // reset to start when reach end
      //   if (
      //     container.scrollLeft >=
      //     container.scrollWidth - container.clientWidth
      //   ) {
      //     container.scrollLeft = 0;
      //   }
      // }, 30); // adjust speed

      // this.scrollInterval = setInterval(() => {
      //   console.log(container.scrollLeft);
      //   container.scrollLeft -= 1; // move left since direction is RTL

      //   // reset when reach the start
      //   // if (container.scrollLeft <= 0) {
      //   //   container.scrollLeft = container.scrollWidth;
      //   // }
      // }, 0.1);
      // const step = () => {
      //   console.log(container.scrollLeft);
      //   // container.scrollLeft = container.scrollLeft - speed;
      //   // console.log(container.scrollLeft);
      //   if (!this.isPaused) {
      //     container.scrollLeft -= 5;
      //     console.log(container.scrollLeft);
      //     if (
      //       container.scrollLeft >=
      //       container.scrollWidth - container.clientWidth
      //     ) {
      //       container.scrollLeft = 0;
      //     }
      //     // move left
      //     // if (container.scrollLeft <= 0) {
      //     //   container.scrollLeft = container.scrollWidth;
      //     // }
      //   }
      //   requestAnimationFrame(step);
      // };

      // requestAnimationFrame(step);
      const step = () => {
        if (!this.isPaused) {
          container.scrollLeft -= 3;

          // seamless scroll: reset when first set scrolls out
          const firstSetWidth = container.scrollWidth / 2;
          if (container.scrollLeft >= firstSetWidth) {
            container.scrollLeft = 0;
          }
        }
        this.scrollAnimationId = requestAnimationFrame(step);
      };

      this.scrollAnimationId = requestAnimationFrame(step);
    }, 3000);
  }

  pauseScroll() {
    this.isPaused = true;
  }

  resumeScroll() {
    this.isPaused = false;
  }

  ngOnDestroy(): void {
    cancelAnimationFrame(this.scrollAnimationId);
  }

  onContentClick(event: Event) {
    const target = event.target as HTMLElement;
    if (target.tagName.toLowerCase() === 'a') {
      const href = target.getAttribute('href');
      if (href && href.startsWith('#')) {
        event.preventDefault();
        const el = document.querySelector(href);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }
    }
  }

  changeFontSize(action: 'smaller' | 'bigger') {
    if (action === 'smaller' && this.fontSize > 10) {
      this.fontSize -= 2;
    } else if (action === 'bigger' && this.fontSize < 40) {
      this.fontSize += 2;
    }
  }

  printContent(data: any) {
    const printWindow = window.open('', '', 'width=800,height=600');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Print</title>
            <style>
              body { font-size: ${this.fontSize}px; line-height: 1.5; }
            </style>
          </head>
          <body>
            ${data}
          </body>
        </html>
      `);
      printWindow.document.close();
      setTimeout(() => {
        printWindow.print();
      }, 1000);
    }
  }
}
