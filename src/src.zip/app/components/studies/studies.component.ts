import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Component, OnInit, HostListener } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { ApiServiceService } from '../../services/api-service.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SocialLinksComponent } from '../social-links/social-links.component';

@Component({
  selector: 'app-studies',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NgbModule,
    SocialLinksComponent,
  ],
  templateUrl: './studies.component.html',
  styleUrls: ['./studies.component.css'],
})
export class StudiesComponent implements OnInit {
  studies: any[] = [];
  page = 1;
  pageSize = 10;
  pageSizes = [10, 50, 100, 200, 300, 400];
  size = 0;
  public isActive: any = true;
  search = '';
  url = 'studies';
  hideImages = true;
  loading = false;
  totalPages: any;

  constructor(private apiService: ApiServiceService, private router: Router) {}

  ngOnInit(): void {
    this.get();
  }
  reset() {
    this.studies = [];
    this.page = 1;
  }
  get() {
    if (this.loading || this.page > this.totalPages) return; // avoid duplicate requests
    this.loading = true;
    this.apiService
      .getAll(this.url, this.search, this.page, this.pageSize)
      .subscribe(
        (data: any) => {
          this.studies = [...this.studies, ...data.data];
          this.page++;
          this.totalPages = data.totalPages;
          this.loading = false;
          // this.studies = data.data;
          this.size = data.count;
        },
        (error) => {
          console.log(error);
        }
      );
  }

  handlePageSizeChange(): void {
    this.page = 1;
    this.ngOnInit();
  }

  pageChange(event: any) {
    console.log(event);
    this.page = event;
    window.scrollTo(0, 0);
    this.get();
  }

  isLongText(text: any): boolean {
    return text && text.length > 300;
  }

  openInNewTab(id: string) {
    // Assuming you have a study details route like /study/:id
    this.router.navigate(['/studies/' + id]);
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const pos =
      (document.documentElement.scrollTop || document.body.scrollTop) +
      window.innerHeight;
    const max = document.documentElement.scrollHeight;

    if (pos >= max - 400) {
      // 50px before reaching bottom
      this.get();
    }
  }
  // onDivScroll(event: any) {
  //   //   const target = event.target;
  //   //   if (target.offsetHeight + target.scrollTop >= target.scrollHeight - 50) {
  //   //     this.get();
  //   //   }
  //   // }
  //   const target = event.target;
  //   const pos = target.scrollTop + target.offsetHeight;
  //   const max = target.scrollHeight;

  //   if (pos >= max - 50) {
  //     // near bottom
  //     this.get();
  //   }
  // }

  getUrl(data: any) {
    return window.location.href + '/' + data;
  }
}
