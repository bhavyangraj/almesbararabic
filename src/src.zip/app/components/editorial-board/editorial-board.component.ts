import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // 👈 needed for ngIf, ngFor, etc.
import { FormsModule } from '@angular/forms'; // 👈 if you're using [(ngModel)]
import { Router, RouterModule } from '@angular/router'; // 👈 if template uses routerLink
import { ApiServiceService } from '../../services/api-service.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-editorial-board',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, NgbModule],
  templateUrl: './editorial-board.component.html',
  styleUrl: './editorial-board.component.css',
})
export class EditorialBoardComponent implements OnInit {
  studiesintolerances: any[] = [];
  page = 1;
  pageSize = 10;
  pageSizes = [10, 50, 100, 200, 300, 400];
  size = 0;
  public isActive: any = true;
  search = '';
  url = 'getAllAuthors';
  hideImages = true;

  constructor(private apiService: ApiServiceService, private router: Router) {}

  ngOnInit(): void {
    this.get();
  }

  get() {
    this.apiService
      .getAll(this.url, this.search, this.page, this.pageSize)
      .subscribe(
        (data: any) => {
          this.studiesintolerances = data.data;
          this.size = data.count;
        },
        (error) => {
          console.log(error);
        }
      );
  }

  handlePageSizeChange(): void {
    this.page = 1;
    this.get();
  }

  pageChange(event: any) {
    this.page = event;
    window.scrollTo(0, 0);
    this.get();
  }
  isLongText(text: any): boolean {
    return text && text.length > 300;
  }

  openInNewTab(id: string) {
    // Assuming you have a study details route like /study/:id
    this.router.navigate(['/editorialboard/' + id]);
  }
}
